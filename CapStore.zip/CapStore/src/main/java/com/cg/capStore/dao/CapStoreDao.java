package com.cg.capStore.dao;


import java.sql.Date;
import java.time.LocalDate;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.capStore.bean.CapStore;

@Repository
public interface CapStoreDao extends JpaRepository<CapStore,Date>{
	
	@Query("select capDate from CapStore where capDate=(select max(capDate) from CapStore)")
	Date getCapStoreDetails();
	
	/*@Query("select sysdate from dual")
	Date getSystemDate();*/
	
	
	/*@Query(value = "insert into CapStore VALUES (:sdate,:amount)", nativeQuery = true)
	
	void updateCapStoreRevenue(@Param("sdate") Date sdate,@Param("amount") double amount);*/

}
